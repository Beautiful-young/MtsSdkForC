#ifndef __UafMessageDefine_H
#define __UafMessageDefine_H


const char* EXE_SIMPLEPUBKEY = "simplepubkey";
const char* EXE_DEVID = "devid";
const char* EXE_NONID = "nonid";

#endif /* !__UafMessageDefine_H*/
