#ifndef __Base64Decode_H
#define __Base64Decode_H

int Base64Url_Decode(const unsigned char *szDecoding, size_t nSize, unsigned char *szOutput, size_t *pnOutSize);

#endif /* !__Base64Decode_H*/