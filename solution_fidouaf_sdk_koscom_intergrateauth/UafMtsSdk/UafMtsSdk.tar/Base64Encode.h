#ifndef __Base64Encode_H
#define __Base64Encode_H


int Base64Url_Encode(const unsigned char *szEncoding, size_t nSize, unsigned char *sOutput, size_t *pnOutSize);


#endif /* DEBUG*/