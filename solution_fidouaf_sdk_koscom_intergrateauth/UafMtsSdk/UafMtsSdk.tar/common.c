#include "common.h"

/* read as number of bits (nNumBits) as wanted from input */
size_t Base64_read_bits(Base64Context *pbContext, int nNumBits, int *pBitsRead, size_t *lp)
{
	long lScratch;
	int c;

	/* if remain bits number of lBitStorage is less than 'nNumBits' and it is not end of input,
	* one byte (eight bits) is readed to buffer (lBitStorage) from input */
	while ((pbContext->m_nBitsRemaining < nNumBits) && ((*lp) < pbContext->m_nInputSize))
	{
		c = pbContext->m_szInput[(*lp)++];
		pbContext->m_lBitStorage <<= 8;
		pbContext->m_lBitStorage |= (c & 0xff);
		pbContext->m_nBitsRemaining += 8;
	}

	if (pbContext->m_nBitsRemaining < nNumBits) /* if end of input */
	{
		lScratch = pbContext->m_lBitStorage << (nNumBits - pbContext->m_nBitsRemaining);
		/* ���ڶ�� ��Ʈ�� shift �������� ���� ���� ��Ʈ�� �����ʿ� 0���� ä���� */
		*pBitsRead = pbContext->m_nBitsRemaining;
		pbContext->m_nBitsRemaining = 0;
	}
	else /* if number of bits in lBitStorage is greater than or equal to nNumBits */
	{
		lScratch = pbContext->m_lBitStorage >> (pbContext->m_nBitsRemaining - nNumBits);
		*pBitsRead = nNumBits;
		pbContext->m_nBitsRemaining -= nNumBits;
	}

	return (size_t)lScratch & m_nMask[nNumBits]; /* Base64�� ��� �Է��� ���� �����ϰ� �׻� 6��Ʈ ��� */
}

/* nBits : bits to output , nNumBits : number of bits to output */
void Base64_write_bits(Base64Context *pbContext, size_t nBits, int nNumBits, unsigned char *szOutput, size_t *index)
{
	unsigned char nScratch;

	pbContext->m_lBitStorage = (pbContext->m_lBitStorage << nNumBits) | nBits;
	pbContext->m_nBitsRemaining += nNumBits;

	while (pbContext->m_nBitsRemaining > 7)
	{
		nScratch = (unsigned char)(pbContext->m_lBitStorage >> (pbContext->m_nBitsRemaining - 8));
		szOutput[(*index)++] = (unsigned char)(nScratch & 0xFF);
		pbContext->m_nBitsRemaining -= 8;
	}
}

size_t Base64_GetEncodeLength(size_t nInputLen)
{
	size_t nInputBitLen = 0, nB64UnitLen = 0,
		nPaddingLen = 0, nRetVal = 0;

	if (nInputLen == 0)
		return nRetVal;

	nInputBitLen = nInputLen * 8;				/* ��Ʈ�� ���.  1byte = 8bit. */
	nB64UnitLen = (nInputBitLen + 5) / 6;		/* B64 char ���� ���. 6:8�� �þ. */
	nPaddingLen = (nB64UnitLen + 1) % 4;			/* �е� ���� ���.  �ƿ�ǲ�� ���̴� �׻� 4�� ����̾�� �ϱ� ������. */
	nPaddingLen = nPaddingLen ^ 0x00000001;
	nRetVal = nB64UnitLen + nPaddingLen;	/* ��ü ��� ���� ��� */

	return nRetVal;
}

size_t uuid_v4_gen(char *buffer)
{
	union
	{
		struct
		{
			uint32_t time_low;
			uint16_t time_mid;
			uint16_t time_hi_and_version;
			uint8_t  clk_seq_hi_res;
			uint8_t  clk_seq_low;
			uint8_t  node[6];
		};
		uint8_t __rnd[16];
	} uuid;

	int rc = RAND_bytes(uuid.__rnd, sizeof(uuid));

	uuid.clk_seq_hi_res = (uint8_t)((uuid.clk_seq_hi_res & 0x3F) | 0x80);
	uuid.time_hi_and_version = (uint16_t)((uuid.time_hi_and_version & 0x0FFF) | 0x4000);

	snprintf(buffer, 38, "%08x-%04x-%04x-%02x%02x-%02x%02x%02x%02x%02x%02x",
		uuid.time_low, uuid.time_mid, uuid.time_hi_and_version,
		uuid.clk_seq_hi_res, uuid.clk_seq_low,
		uuid.node[0], uuid.node[1], uuid.node[2],
		uuid.node[3], uuid.node[4], uuid.node[5]);

	return rc;
}

size_t getSessionID(char *buffer)
{
	union
	{
		struct
		{
			uint32_t time_low;
			uint16_t time_mid;
			uint16_t time_hi_and_version;
			uint8_t  clk_seq_hi_res;
			uint8_t  clk_seq_low;
			uint8_t  node[6];
		};
		uint8_t __rnd[16];
	} uuid;

	int rc = RAND_bytes(uuid.__rnd, sizeof(uuid));

	uuid.clk_seq_hi_res = (uint8_t)((uuid.clk_seq_hi_res & 0x3F) | 0x80);
	uuid.time_hi_and_version = (uint16_t)((uuid.time_hi_and_version & 0x0FFF) | 0x4000);

	snprintf(buffer, 38, "%08x%04x%04x%02x%02x%02x%02x%02x%02x%02x%02x",
		uuid.time_low, uuid.time_mid, uuid.time_hi_and_version,
		uuid.clk_seq_hi_res, uuid.clk_seq_low,
		uuid.node[0], uuid.node[1], uuid.node[2],
		uuid.node[3], uuid.node[4], uuid.node[5]);

	return rc;
}